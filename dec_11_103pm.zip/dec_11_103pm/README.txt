bin\neo4j-admin dump --database=graph.db --to=D:\neo4j_backup\graph.db\dec11_103pm.dump
bin\neo4j-admin load --from=D:\neo4j_backup\graph.db\dec11_103pm.dump --database=graph.db --force
https://neo4j.com/docs/operations-manual/current/tools/dump-load/
Same for both Windows and Ubuntu, neo4j-admin
